﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace AdminClient.Forms
{
    public partial class CommandCode : AdminClient.BaseForm.FormSerchListTemp
    {
        public CommandCode()
        {
            InitializeComponent();
        }
    }
}
