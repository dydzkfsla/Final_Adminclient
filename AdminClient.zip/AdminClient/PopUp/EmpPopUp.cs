﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace AdminClient.PopUp
{
    public partial class EmpPopUp : AdminClient.BaseForm.EmpFormTemp
    {
        public EmpPopUp()
        {
            InitializeComponent();
        }

        private void pnl_Main_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}
