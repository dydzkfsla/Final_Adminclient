﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace AdminClient.Serch
{
    public partial class WareHouseSearch : AdminClient.BaseForm.FormSearchTemp
    {
        public WareHouseSearch()
        {
            InitializeComponent();
        }
    }
}
